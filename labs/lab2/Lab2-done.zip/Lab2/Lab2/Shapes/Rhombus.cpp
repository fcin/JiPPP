#include "Rhombus.h"

namespace Labs
{
	Rhombus::Rhombus(Point2D center, double diag1, double diag2)
		: m_Center(center), m_Diagonal1(diag1), m_Diagonal2(diag2) { }
}